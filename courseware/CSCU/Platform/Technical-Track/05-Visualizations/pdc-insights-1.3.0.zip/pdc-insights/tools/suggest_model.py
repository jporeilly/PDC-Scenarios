"""Suggest an Ollama model + run command based on this machine's hardware.

Generation in Catalog Insights targets one JSON schema, so even small models do
well — but on CPU, model size and quantization dominate latency. This probes the
OS, RAM, CPU cores, and any NVIDIA GPU, then recommends a model tier and the
right run command for the platform. No dependencies beyond the standard library.

Run:  python tools/suggest_model.py
"""
from __future__ import annotations

import os
import platform
import shutil
import subprocess


def _gpu_vram_gb() -> float | None:
    """Total NVIDIA VRAM in GB via nvidia-smi, or None if no NVIDIA GPU."""
    if not shutil.which("nvidia-smi"):
        return None
    try:
        out = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"],
            text=True, timeout=10,
        )
        # Sum across cards (Ollama can split layers across multiple GPUs).
        return round(sum(int(x) for x in out.split()) / 1024, 1)
    except Exception:  # noqa: BLE001 — detection must never crash
        return None


def _ram_gb() -> float:
    """Total system RAM in GB, best-effort across platforms."""
    # Linux / most POSIX
    try:
        return round(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 1024**3, 1)
    except (ValueError, OSError, AttributeError):
        pass
    if platform.system() == "Darwin":  # macOS
        try:
            return round(int(subprocess.check_output(["sysctl", "-n", "hw.memsize"])) / 1024**3, 1)
        except Exception:  # noqa: BLE001
            pass
    if platform.system() == "Windows":
        try:
            out = subprocess.check_output(
                ["wmic", "ComputerSystem", "get", "TotalPhysicalMemory"], text=True)
            return round(int(out.split()[-1]) / 1024**3, 1)
        except Exception:  # noqa: BLE001
            pass
    return 0.0


# (model, why) tiers, richest first. Chosen for reliable JSON spec generation.
GPU_TIERS = [
    (20, "qwen2.5:32b-instruct", "lots of VRAM — but 32B is overkill for spec JSON; 14B is plenty"),
    (9,  "qwen2.5:14b-instruct", "comfortable headroom for stronger chart-type choices"),
    (5,  "qwen2.5:7b-instruct",  "fast and strong at JSON — the recommended default"),
    (0,  "qwen2.5:3b-instruct",  "small GPU — a 3B keeps things responsive"),
]
CPU_TIERS = [
    (32, "qwen2.5:7b-instruct",  "plenty of RAM; 7B (Q4) runs on CPU, just slower than GPU"),
    (16, "qwen2.5:3b-instruct",  "3B is the sweet spot for CPU-only — usable latency"),
    (8,  "qwen2.5:1.5b-instruct", "limited RAM — a 1.5B keeps generation tractable"),
    (0,  "qwen2.5:0.5b-instruct", "very limited RAM — smallest model; expect weaker specs"),
]


def recommend() -> dict:
    """Return {mode, model, why, ram_gb, vram_gb, cores, run_cmd, set_env}."""
    system = platform.system()
    cores = os.cpu_count() or 1
    ram = _ram_gb()
    vram = _gpu_vram_gb()

    if vram:  # NVIDIA GPU present
        mode = "gpu"
        model, why = next((m, w) for thresh, m, w in GPU_TIERS if vram >= thresh)
    else:
        mode = "cpu"
        model, why = next((m, w) for thresh, m, w in CPU_TIERS if ram >= thresh)

    # Platform-appropriate native run command for the web app.
    if system == "Windows":
        run_cmd = "waitress-serve --port=8660 wsgi:app   # pip install waitress"
    else:
        run_cmd = "gunicorn --bind 0.0.0.0:8660 --threads 4 wsgi:app"

    # On CPU, fewer Ollama threads than cores often helps; surface a hint.
    set_env = "OLLAMA_NUM_PARALLEL=1" if mode == "cpu" else None
    return {"mode": mode, "model": model, "why": why, "ram_gb": ram,
            "vram_gb": vram, "cores": cores, "system": system,
            "run_cmd": run_cmd, "set_env": set_env}


def main() -> None:
    r = recommend()
    hw = f"{r['system']} · {r['cores']} cores · {r['ram_gb']} GB RAM"
    hw += f" · GPU {r['vram_gb']} GB VRAM" if r["vram_gb"] else " · no NVIDIA GPU"
    print(f"\nDetected: {hw}")
    print(f"Mode:     {r['mode'].upper()}")
    print(f"\nRecommended model:\n  ollama pull {r['model']}\n  ({r['why']})")
    print(f"\nSet in .env:\n  LLM_PROVIDER=local")
    print(f"  LLM_MODEL={r['model']}")
    print(f"  LLM_BASE_URL=http://localhost:11434   # native Ollama on this host")
    if r["set_env"]:
        print(f"\nCPU tip: also set {r['set_env']} for Ollama, and expect slower "
              f"generation than GPU — keep LLM_JSON_MODE=true.")
    print(f"\nRun the web app natively:\n  {r['run_cmd']}\n")


if __name__ == "__main__":
    main()
