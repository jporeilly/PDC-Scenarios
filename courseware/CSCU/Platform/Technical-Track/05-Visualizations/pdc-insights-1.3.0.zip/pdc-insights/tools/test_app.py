"""Functional tests — run: python tools/test_app.py

Exercises the catalog/recommend engine, the conversational builder, and the web
routes that back the in-app chat. Runs entirely on the bundled demo snapshot
with the LLM disabled, so it needs no live PDC and no model — the deterministic
builder path is what's under test here. Security (auth/roles/audit) has its own
suite in tools/test_security.py.
"""
import os
import sys

# Demo data + open auth + no model: forces the offline/deterministic paths.
os.environ.update({"INSIGHTS_DEMO": "true", "INSIGHTS_AUTH": "none",
                   "LLM_PROVIDER": "disabled"})
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import json  # noqa: E402

from app import create_app  # noqa: E402
from app.catalog import QUERY_CATALOG, catalog_snapshot  # noqa: E402
from app.chat_build import conversation_prompt, demo_build  # noqa: E402
from app.generator import _validate  # noqa: E402
from app.recommend import recommend  # noqa: E402

SECTIONS = ["overview", "system", "user", "governance", "quality", "sensitivity"]
PASS, FAIL = "✓", "✗"
fails = 0


def check(label, cond):
    global fails
    print(f"  {PASS if cond else FAIL} {label}")
    if not cond:
        fails += 1


print("\n[1] recommend — section awareness")
snap = catalog_snapshot()
for sec in SECTIONS:
    recs = recommend(snap, category=sec)
    # every section must offer at least one suggestion …
    check(f"{sec}: has suggestions ({len(recs)})", len(recs) >= 1)
    # … and every suggestion must belong to that section
    check(f"{sec}: all suggestions match section",
          all(r["category"] == sec for r in recs))
# unfiltered returns more than any single section; scope narrows to one source
check("unfiltered returns the full set", len(recommend(snap)) > len(recommend(snap, category="user")))
scoped = recommend(snap, scope="S3-raw")
check("scope=S3-raw yields only S3-raw suggestions",
      scoped and all("S3-raw" in (r.get("scope") or "") or "S3" in r["title"] for r in scoped))
# suggestions carry the fields the chat relies on
first = recommend(snap, category="sensitivity")[0]
check("suggestion has why + generate_prompt + template + priority",
      all(k in first for k in ("why", "generate_prompt", "standard_template", "priority")))

print("\n[2] chat_build — deterministic builder")
for sec in SECTIONS:
    r = demo_build("something useful", section=sec)
    check(f"{sec}: builds a valid spec pinned to the section",
          r["valid"] and r["spec"]["category"] == sec and not _validate(r["spec"], QUERY_CATALOG))
# keyword routing when no section is pinned
check("keywords route 'PII exposure' → sensitivity",
      demo_build("show me PII exposure")["spec"]["category"] == "sensitivity")
check("keywords route 'quality scores' → quality",
      demo_build("quality scores and worst tables")["spec"]["category"] == "quality")
# prompt assembly carries the section and the current spec
p = conversation_prompt([{"role": "user", "content": "add a trend"}],
                        spec={"title": "x"}, section="governance")
check("conversation_prompt pins section + includes current spec",
      "governance" in p and "current dashboard spec" in p)

print("\n[3] web routes")
app = create_app()
c = app.test_client()
check("GET /chat serves the builder", c.get("/chat").status_code == 200)
check("GET /api/recommend?section=quality is quality-only",
      all(r["category"] == "quality"
          for r in c.get("/api/recommend?section=quality").get_json()))

# build via the chat endpoint, pinned to a section
r = c.post("/api/chat", json={"messages": [{"role": "user", "content": "anything"}],
                              "section": "user"})
body = r.get_json()
check("POST /api/chat builds (200, valid)", r.status_code == 200 and body["valid"])
check("chat respects the pinned section", body["spec"]["category"] == "user")
check("chat reports the offline engine", body.get("engine") == "demo")
check("chat returns an assistant reply", bool(body.get("reply")))
check("POST /api/chat with no messages → 400",
      c.post("/api/chat", json={"messages": []}).status_code == 400)

# refine: send the spec back with a follow-up, expect a still-valid spec
r2 = c.post("/api/chat", json={"messages": [
    {"role": "user", "content": "build a user dashboard"},
    {"role": "user", "content": "add owner workload"}], "spec": body["spec"]})
check("refine turn returns a valid spec", r2.get_json()["valid"])

# the built spec saves through the normal (validated) dashboards route
save = c.post("/api/dashboards", json=body["spec"])
check("built spec saves via /api/dashboards", save.status_code == 200 and save.get_json().get("saved"))

# download a standard spec as an attachment (the app's Download button)
dl = c.get("/api/dashboards/sensitivity/pii-discoveries/download")
check("GET …/download returns the spec", dl.status_code == 200 and dl.get_json().get("title"))
check("download sets attachment filename",
      "attachment" in dl.headers.get("Content-Disposition", "") and
      "pii-discoveries.studio.json" in dl.headers.get("Content-Disposition", ""))
check("download of a missing spec → 404",
      c.get("/api/dashboards/sensitivity/nope/download").status_code == 404)

print("\n[4] generator validation still guards")
bad = {"version": 1, "title": "bad", "category": "overview",
       "panels": [{"id": "p", "kind": "chart", "title": "t",
                   "query": "not_a_real_query", "chartType": "bar", "bindings": {}}]}
check("invalid spec is rejected by _validate", len(_validate(bad, QUERY_CATALOG)) > 0)

print(f"\n{'ALL PASS' if not fails else str(fails)+' FAILED'}")
# tidy any dashboard the save test wrote
try:
    import glob
    import re
    from pathlib import Path
    keep = {"catalog-health", "risk-hotspots", "profiling-health", "source-inventory",
            "stewardship", "activity-ratings", "glossary-coverage", "policy-lineage",
            "quality-scores", "dq-dimensions", "exposure-overview", "pii-discoveries"}
    for f in glob.glob("app/dashboards/**/*.studio.json", recursive=True):
        if Path(f).stem not in keep:
            os.remove(f)
except Exception:
    pass

sys.exit(1 if fails else 0)
