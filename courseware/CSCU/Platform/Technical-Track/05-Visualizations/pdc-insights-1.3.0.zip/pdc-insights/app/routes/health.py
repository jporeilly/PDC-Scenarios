"""Liveness + dependency reachability (PDC, LLM)."""
from flask import Blueprint, jsonify

from ..config import settings
from ..llm import get_provider
from ._auth import require

bp = Blueprint("health", __name__)


@bp.get("/health")
def health():
    # Public: no auth — used by orchestration health checks.
    return jsonify({"status": "ok", "brand": settings.brand.name})


@bp.get("/config")
@require("viewer")
def config():
    return jsonify({
        "brand": {"name": settings.brand.name, "product": settings.brand.product,
                  "accent": settings.brand.accent},
        "pdc": {"base_url": settings.pdc.base_url, "version": settings.pdc.version},
        "llm": {"provider": settings.llm.provider, "model": settings.llm.model},
        "auth": {"mode": __import__("os").getenv("INSIGHTS_AUTH", "none")},
    })


@bp.get("/health/llm")
@require("viewer")
def health_llm():
    return jsonify(get_provider().health())
