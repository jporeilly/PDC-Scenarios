"""Thin client over the PDC public REST API.

This module is the *only* place in the codebase that talks HTTP to Pentaho
Data Catalog. Everything else (the web routes, the generator, the MCP tools,
the recommender) goes through this client, so there is exactly one spot to
reason about authentication, caching, and PDC's quirks.

Design rules baked in here:

* READ-ONLY.  Reporting only needs to read. We deliberately expose no method
  that mutates the catalog, which keeps the security blast radius tiny: even a
  fully compromised caller can't change PDC through this app (see SECURITY.md).

* API IS THE CONTRACT.  PDC stores data in OpenSearch (search/facets), MongoDB
  (operational metadata; FerretDB/Postgres in PDC 11), and a BIDB. We never
  touch those engines directly — only the public REST API, which shields us
  from PDC's internal storage changes across versions.

Endpoints used (all under {base}/api/public/{version}):
  POST /auth              -> bearer token (a short-lived JWT)
  POST /search            -> paginated asset rows
  POST /search/facets     -> pre-aggregated counts  ← the dashboard workhorse
  POST /entities/filter   -> full entity attributes (cursor-paginated)
  GET  /data-sources      -> connected sources / scan inventory

Trust-score note: READING trust scores via search/facets works on every tested
build. TRIGGERING a recalculation through the public API is version-dependent,
so this client intentionally exposes no "calculate" call (see PDC-CONNECTOR.md).
"""
from __future__ import annotations

import time
from typing import Any

import requests

from .config import settings

# PDC's standard trust-score banding. Reused by trust_distribution() and mirrored
# in the UI's "trust spectrum". Ranges are inclusive: 0–50, 51–75, 76–100.
_TRUST_BUCKETS = [
    ("Untrusted", 0, 50),
    ("Trusted", 51, 75),
    ("Highly Trusted", 76, 100),
]


class PDCError(RuntimeError):
    """Raised for PDC-specific problems (missing creds, malformed auth reply).

    HTTP-level failures surface as requests.HTTPError via raise_for_status();
    this is for the cases the HTTP layer can't express on its own.
    """


class PDCClient:
    """Stateful client holding a cached bearer token and a small response cache.

    One module-level instance (`client`, created at the bottom) is shared by the
    whole process. It is safe to share because the only mutable state is the
    token and the TTL cache, both of which tolerate concurrent overwrite
    (last-write-wins) under the threaded gunicorn workers we run.
    """

    def __init__(self, cfg=settings.pdc):
        self.cfg = cfg
        # If a long-lived token was supplied in config, seed it; otherwise we'll
        # fetch one lazily on first use via token().
        self._token: str | None = cfg.bearer_token or None
        # cache_key -> (stored_at_epoch, payload). Bounded only by the number of
        # distinct queries; fine for a reporting workload. TTL from PDC_CACHE_TTL.
        self._cache: dict[str, tuple[float, Any]] = {}

    # ── auth ─────────────────────────────────────────────────
    def token(self) -> str:
        """Return a valid bearer token, fetching one if we don't have it.

        PDC's POST /auth is OAuth-style: it expects FORM-ENCODED fields (not
        JSON) and returns the JWT under data.accessToken. client_id/grant_type/
        scope have server-side defaults, but we send them to match the documented
        contract exactly. The token is cached on the instance; _request() clears
        it on a 401 so the next call re-authenticates (PDC tokens are short-lived
        with no refresh).
        """
        if self._token:
            return self._token
        if not (self.cfg.username and self.cfg.password):
            raise PDCError("No PDC credentials configured")
        resp = requests.post(
            f"{self.cfg.api_root}/auth",
            data={  # form-encoded, NOT json=
                "username": self.cfg.username,
                "password": self.cfg.password,
                "client_id": "pdc-client",
                "grant_type": "password",
                "scope": "openid profile email",
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            verify=self.cfg.verify_tls,
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json().get("data", {})
        # accessToken is the documented field; tolerate older shapes just in case.
        self._token = data.get("accessToken") or data.get("token")
        if not self._token:
            raise PDCError("Auth succeeded but no accessToken in response")
        return self._token

    def _headers(self) -> dict[str, str]:
        """Standard auth + JSON headers for every PDC call."""
        return {"Authorization": f"Bearer {self.token()}",
                "Content-Type": "application/json"}

    # ── low-level request plumbing ───────────────────────────
    def _post(self, path: str, body: dict, cache_key: str | None = None) -> dict:
        """POST helper with an optional read-through TTL cache.

        Facet/snapshot reads are the same a few times per dashboard load, so a
        short TTL cache (PDC_CACHE_TTL seconds) noticeably cuts PDC round-trips.
        Pass cache_key only for idempotent reads that are safe to serve stale.
        """
        if cache_key and self.cfg.cache_ttl:
            hit = self._cache.get(cache_key)
            if hit and (time.time() - hit[0]) < self.cfg.cache_ttl:
                return hit[1]  # fresh enough — skip the network
        data = self._request("post", path, json=body)
        if cache_key and self.cfg.cache_ttl:
            self._cache[cache_key] = (time.time(), data)
        return data

    def _request(self, method: str, path: str, **kwargs) -> dict:
        """Send a request, re-authenticating once on 401.

        PDC's JWTs are short-lived and there is no refresh token, so a token we
        cached earlier may have expired mid-session. On the first 401 we drop the
        cached token (forcing token() to re-auth with credentials) and retry
        once. We skip the retry when a fixed bearer token was configured, since
        re-auth wouldn't help in that case.
        """
        url = f"{self.cfg.api_root}{path}"
        for attempt in (1, 2):
            resp = requests.request(method, url, headers=self._headers(),
                                    verify=self.cfg.verify_tls, timeout=60, **kwargs)
            if resp.status_code == 401 and attempt == 1 and not self.cfg.bearer_token:
                self._token = None  # expired/invalid — force re-auth and retry
                continue
            resp.raise_for_status()
            return resp.json()
        # Both attempts 401'd: raise the second response's error for the caller.
        resp.raise_for_status()
        return resp.json()

    # ── reads ────────────────────────────────────────────────
    def facets(self, term: str = "*", facets: dict | None = None) -> list[dict]:
        """Return pre-aggregated counts for a query — the dashboard workhorse.

        Shape: [{ key, options: [{ name, value, count }] }]. Because PDC does the
        aggregation in OpenSearch, one call yields a ready-to-plot series with no
        client-side grouping. `facets` constrains the query (e.g. {"type":["TABLE"]}).
        Cached per (term, facets).
        """
        body = {"searchTerm": term, "searchFacets": facets or {}}
        # Stable cache key: sort the facet items so equivalent filters collide.
        key = f"facets::{term}::{sorted((facets or {}).items())}"
        return self._post("/search/facets", body, cache_key=key).get("data", [])

    def search(self, term: str = "*", facets: dict | None = None,
               page: int = 1, per_page: int = 30) -> dict:
        """Paginated asset rows (the full /search response, incl. pageInfo).

        Not cached: row-level results vary by page and are less hot than facets.
        Returns the raw payload so callers can read totalMatchCount from pageInfo.
        """
        body = {"searchTerm": term, "searchFacets": facets or {},
                "page": page, "perPage": per_page}
        return self._post("/search", body)

    def entities(self, filters: dict, size: int = 500, extended: bool = True):
        """Yield full entity records, transparently following cursor pagination.

        /entities/filter returns large result sets in pages keyed by an opaque
        cursor. This generator hides that: it keeps fetching and yielding until
        PDC stops returning a cursor. `extended=True` asks for the full attribute
        set (qualityScore, trustScore, sensitivity, owners, PII discoveries, …).
        Use it when you need per-asset detail rather than facet counts.
        """
        cursor = None
        while True:
            params = f"?size={size}&extended={str(extended).lower()}"
            if cursor:
                params += f"&cursor={cursor}"
            data = self._post(f"/entities/filter{params}", {"filters": filters})
            yield from data.get("data", [])
            cursor = data.get("cursorInfo", {}).get("cursor")
            if not cursor:  # no further pages
                break

    def trust_distribution(self, term: str = "*") -> list[dict]:
        """Count assets in each trust band — a small convenience over search().

        Runs one tiny (per_page=1) search per band and reads the total match
        count, so we get the three-bucket distribution without pulling any rows.
        Returns [{name, count}] in Untrusted/Trusted/Highly-Trusted order.
        """
        rows = []
        for label, lo, hi in _TRUST_BUCKETS:
            res = self.search(term, {"trustScore": [lo, hi]}, per_page=1)
            rows.append({"name": label,
                         "count": res.get("pageInfo", {}).get("totalMatchCount", 0)})
        return rows

    # ── data sources / connections ───────────────────────────
    def data_sources(self) -> list[dict]:
        """List connected data sources (databases, files, cloud stores).

        GET /data-sources — read-only. This is the connection/scan inventory the
        recommender reasons over ("what's connected, how fresh is each scan") to
        suggest dashboards. Returns the raw list under the response's "data" key.
        """
        resp = requests.get(
            f"{self.cfg.api_root}/data-sources",
            headers=self._headers(),
            verify=self.cfg.verify_tls,
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json().get("data", [])


# Process-wide singleton. Importing `client` everywhere keeps a single token +
# cache rather than re-authenticating per call site.
client = PDCClient()
