"""Configuration, loaded once from the environment.

One place to read every setting, so the PDC client, the LLM providers, the
security layer, and the routes all share the same source of truth instead of
scattering os.getenv() calls. Settings are frozen dataclasses populated from the
environment at import time (see .env.example for the full list and docs).

Note: security/auth settings are intentionally read directly from os.getenv()
inside app.security (not mirrored here), so security behaviour is governed in one
self-contained module.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field


def _bool(name: str, default: bool) -> bool:
    """Parse a boolean env var, accepting the usual truthy spellings."""
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Brand:
    """White-label knobs so the product can be renamed per delivery, mirroring
    the Glossary Generator's GLOSSARY_* pattern."""
    name: str = os.getenv("INSIGHTS_BRAND_NAME", "Catalog Insights")
    product: str = os.getenv("INSIGHTS_BRAND_PRODUCT", "Pentaho Data Catalog")
    accent: str = os.getenv("INSIGHTS_BRAND_ACCENT", "#0F766E")


@dataclass(frozen=True)
class PDCConfig:
    """Everything needed to reach and authenticate to a PDC instance."""
    base_url: str = os.getenv("PDC_BASE_URL", "")
    version: str = os.getenv("PDC_API_VERSION", "v3")
    username: str = os.getenv("PDC_USERNAME", "")
    password: str = os.getenv("PDC_PASSWORD", "")
    # Optional long-lived token instead of user/pass (disables 401 re-auth retry).
    bearer_token: str = os.getenv("PDC_BEARER_TOKEN", "")
    verify_tls: bool = _bool("PDC_VERIFY_TLS", True)
    # Seconds to cache idempotent reads (facets/snapshot). 0 disables caching.
    cache_ttl: int = int(os.getenv("PDC_CACHE_TTL", "300"))

    @property
    def api_root(self) -> str:
        """The versioned API base, e.g. https://pdc.host/api/public/v3."""
        return f"{self.base_url.rstrip('/')}/api/public/{self.version}"


@dataclass(frozen=True)
class LLMConfig:
    """Provider-agnostic LLM settings. `provider` selects the backend; the rest
    are interpreted by whichever provider is chosen (see app/llm/)."""
    provider: str = os.getenv("LLM_PROVIDER", "local").lower()
    model: str = os.getenv("LLM_MODEL", "qwen2.5:7b-instruct")
    base_url: str = os.getenv("LLM_BASE_URL", "http://localhost:11434")
    api_key: str = os.getenv("LLM_API_KEY", "")
    # Constrain output to valid JSON (Ollama format=json / OpenAI json_object).
    json_mode: bool = _bool("LLM_JSON_MODE", True)
    timeout: int = int(os.getenv("LLM_TIMEOUT", "120"))
    # Hard ceiling so a runaway prompt can't drain a metered account.
    max_tokens: int = int(os.getenv("LLM_MAX_TOKENS", "4000"))


@dataclass(frozen=True)
class Settings:
    """Top-level settings aggregate. `field(default_factory=...)` builds each
    sub-config lazily so a frozen dataclass can still nest other dataclasses."""
    host: str = os.getenv("INSIGHTS_HOST", "0.0.0.0")
    port: int = int(os.getenv("INSIGHTS_PORT", "8660"))
    log_level: str = os.getenv("INSIGHTS_LOG_LEVEL", "INFO")
    brand: Brand = field(default_factory=Brand)
    pdc: PDCConfig = field(default_factory=PDCConfig)
    llm: LLMConfig = field(default_factory=LLMConfig)


# Import this everywhere; it reflects the environment as of process start.
settings = Settings()
